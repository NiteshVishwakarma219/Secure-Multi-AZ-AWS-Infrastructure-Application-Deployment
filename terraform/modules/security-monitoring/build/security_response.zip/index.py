import json
import os
import boto3

sns = boto3.client("sns")
TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]

def handler(event, context):
    # Minimal, auditable response: notify the security channel.
    # Extend here for automated remediation (isolate instance,
    # revoke a security group rule, disable a key, etc.) once
    # the specific finding types this project handles are decided.
    message = json.dumps(event)
    sns.publish(
        TopicArn=TOPIC_ARN,
        Subject="Security finding detected",
        Message=message,
    )
    return {"status": "notified"}
